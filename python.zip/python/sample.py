import os

from docx import Document

# First, we'll create an empty list to hold the path to all of your docx files
document_list = []       

first_cell_string="is"

# Now, we loop through every file in the folder "G:\GIS\DESIGN\ROW\ROW_Files\Docx" 
# (and all it's subfolders) using os.walk().  You could alternatively use os.listdir()
# to get a list of files.  It would be recommended, and simpler, if all files are
# in the same folder.  Consider that change a small challenge for developing your skills!
for path, subdirs, files in os.walk(r"D:\work work work work work work\python\file"): 
    for name in files:
        # For each file we find, we need to ensure it is a .docx file before adding
        #  it to our list
        if os.path.splitext(os.path.join(path, name))[1] == ".docx":
            document_list.append(os.path.join(path, name))

# Now create a loop that goes over each file path in document_list, replacing your 
# hard-coded path with the variable.
for document_path in document_list:
 document = Document(document_path)
 # create a list of all of the table object with text of the
 # first cell equal to `first_cell_string`
 tables = [t for t in document.tables 
              if t.cell(0,0).text.lower().strip()==first_cell_string]

 # in the case that more than one table is found 
 out = []
 for table in tables:
     for i, row in enumerate(table.rows):
         text = (cell.text for cell in row.cells)
         if i == 0:
             keys = tuple(text)
             continue

         row_data = dict(zip(keys, text))
         data.append(row_data)
     out.append(pd.DataFrame.from_dict(data))
 print(out)